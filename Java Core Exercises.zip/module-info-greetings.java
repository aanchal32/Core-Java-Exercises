// Q34: com.greetings module descriptor
// File location: com.greetings/src/module-info.java
module com.greetings {
    requires com.utils;
}
