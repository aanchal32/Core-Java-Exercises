// Q37: Using javap to Inspect Bytecode
// Compile this file, then inspect with: javap -c BytecodeInspection
public class BytecodeInspection {

    static int square(int n) {
        return n * n;
    }

    static int sumUpTo(int n) {
        int sum = 0;
        for (int i = 1; i <= n; i++) {
            sum += i;
        }
        return sum;
    }

    public static void main(String[] args) {
        System.out.println("square(5) = " + square(5));
        System.out.println("sumUpTo(10) = " + sumUpTo(10));
    }
}

/*
 * Steps to inspect bytecode:
 *
 * 1. Compile:
 *    javac BytecodeInspection.java
 *
 * 2. View bytecode (disassembled):
 *    javap -c BytecodeInspection
 *
 * 3. View with line numbers and local variables:
 *    javap -c -l -verbose BytecodeInspection
 *
 * Sample javap output for square(int):
 *   static int square(int);
 *     Code:
 *        0: iload_0         // load parameter n
 *        1: iload_0         // load parameter n again
 *        2: imul            // multiply top two stack values
 *        3: ireturn         // return int result
 *
 * Key JVM opcodes:
 *   iload_N  – load int from local variable slot N
 *   istore_N – store int to local variable slot N
 *   imul     – integer multiply
 *   iadd     – integer add
 *   if_icmple– if int compare less-or-equal (used for loop condition)
 *   invokestatic – call static method
 *   getstatic    – get static field (e.g., System.out)
 *   invokevirtual– call instance method (e.g., println)
 */
