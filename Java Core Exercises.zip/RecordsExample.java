// Q29: Records (Java 16+)
import java.util.List;
import java.util.stream.Collectors;

public class RecordsExample {

    // Record definition – compact, immutable data carrier
    record Person(String name, int age) {}

    public static void main(String[] args) {
        // Create instances
        Person p1 = new Person("Alice", 30);
        Person p2 = new Person("Bob", 17);
        Person p3 = new Person("Charlie", 25);
        Person p4 = new Person("Diana", 15);

        System.out.println("All persons:");
        List<Person> people = List.of(p1, p2, p3, p4);
        people.forEach(System.out::println);

        // Filter adults using Streams
        List<Person> adults = people.stream()
                .filter(p -> p.age() >= 18)
                .collect(Collectors.toList());

        System.out.println("\nAdults (age >= 18):");
        adults.forEach(p -> System.out.println(p.name() + " - " + p.age()));
    }
}
