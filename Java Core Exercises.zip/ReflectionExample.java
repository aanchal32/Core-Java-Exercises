// Q39: Reflection in Java
import java.lang.reflect.Method;

public class ReflectionExample {

    // Target class to inspect and invoke dynamically
    static class MathOperations {
        public int add(int a, int b)      { return a + b; }
        public int subtract(int a, int b) { return a - b; }
        public int multiply(int a, int b) { return a * b; }
        private int secret()              { return 42; }
    }

    public static void main(String[] args) throws Exception {
        // Load class dynamically
        Class<?> clazz = Class.forName("ReflectionExample$MathOperations");
        Object instance = clazz.getDeclaredConstructor().newInstance();

        // Print all declared methods
        System.out.println("Methods in MathOperations:");
        for (Method m : clazz.getDeclaredMethods()) {
            System.out.println("  " + m.getName() + " - params: " + m.getParameterCount());
        }

        // Invoke a method dynamically by name
        System.out.println("\nDynamic invocations:");
        String[] methodNames = {"add", "subtract", "multiply"};
        int a = 10, b = 3;
        for (String name : methodNames) {
            Method method = clazz.getMethod(name, int.class, int.class);
            Object result = method.invoke(instance, a, b);
            System.out.println(name + "(" + a + ", " + b + ") = " + result);
        }

        // Access private method via reflection
        Method secret = clazz.getDeclaredMethod("secret");
        secret.setAccessible(true);
        System.out.println("\nPrivate method 'secret' result: " + secret.invoke(instance));
    }
}
