// Q32: Insert and Update Operations in JDBC (SQLite)
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class StudentDAO {

    private static final String DB_URL = "jdbc:sqlite:school.db";

    // Initialize table
    static {
        try (Connection conn = DriverManager.getConnection(DB_URL);
             var stmt = conn.createStatement()) {
            stmt.execute("CREATE TABLE IF NOT EXISTS students (id INTEGER PRIMARY KEY, name TEXT, grade TEXT)");
        } catch (Exception e) {
            System.out.println("Init error: " + e.getMessage());
        }
    }

    // Insert a new student record
    public void insertStudent(int id, String name, String grade) {
        String sql = "INSERT INTO students(id, name, grade) VALUES(?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.setString(2, name);
            ps.setString(3, grade);
            int rows = ps.executeUpdate();
            System.out.println("Inserted " + rows + " row(s). Student: " + name);
        } catch (SQLException e) {
            System.out.println("Insert error: " + e.getMessage());
        }
    }

    // Update student grade
    public void updateStudentGrade(int id, String newGrade) {
        String sql = "UPDATE students SET grade = ? WHERE id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, newGrade);
            ps.setInt(2, id);
            int rows = ps.executeUpdate();
            if (rows > 0) {
                System.out.println("Updated student ID " + id + " grade to: " + newGrade);
            } else {
                System.out.println("No student found with ID: " + id);
            }
        } catch (SQLException e) {
            System.out.println("Update error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        StudentDAO dao = new StudentDAO();
        dao.insertStudent(10, "Eve", "B");
        dao.insertStudent(11, "Frank", "C");
        dao.updateStudentGrade(10, "A");
        dao.updateStudentGrade(99, "A"); // non-existent ID
    }
}
