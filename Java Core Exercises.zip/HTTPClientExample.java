// Q36: HTTP Client API (Java 11+)
// Fetches public user data from GitHub API
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class HTTPClientExample {
    public static void main(String[] args) throws Exception {
        HttpClient client = HttpClient.newHttpClient();

        // GitHub public API – no auth needed for public info
        String url = "https://api.github.com/users/torvalds";

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Accept", "application/vnd.github.v3+json")
                .GET()
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        System.out.println("Status: " + response.statusCode());
        System.out.println("Response Body:");
        System.out.println(response.body());

        // Optional: parse JSON manually (basic field extraction without a library)
        String body = response.body();
        extractField(body, "login");
        extractField(body, "name");
        extractField(body, "public_repos");
        extractField(body, "followers");
    }

    // Simple JSON field extractor (without external library)
    static void extractField(String json, String field) {
        String key = "\"" + field + "\":";
        int idx = json.indexOf(key);
        if (idx == -1) return;
        int start = idx + key.length();
        // Skip spaces and quotes
        while (start < json.length() && (json.charAt(start) == ' ' || json.charAt(start) == '"')) start++;
        int end = start;
        while (end < json.length() && json.charAt(end) != '"' && json.charAt(end) != ',' && json.charAt(end) != '}') end++;
        System.out.println(field + ": " + json.substring(start, end));
    }
}
