// Q6: Data Type Demonstration
public class DataTypeDemo {
    public static void main(String[] args) {
        int myInt = 42;
        float myFloat = 3.14f;
        double myDouble = 2.718281828;
        char myChar = 'J';
        boolean myBoolean = true;

        System.out.println("int:     " + myInt);
        System.out.println("float:   " + myFloat);
        System.out.println("double:  " + myDouble);
        System.out.println("char:    " + myChar);
        System.out.println("boolean: " + myBoolean);
    }
}
