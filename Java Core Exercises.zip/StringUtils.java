// Q34: Utility class in com.utils module
package com.utils;

public class StringUtils {
    public static String greet(String name) {
        return "Hello, " + name + "! Welcome to Java Modules.";
    }

    public static String repeat(String text, int times) {
        return text.repeat(times);
    }
}
