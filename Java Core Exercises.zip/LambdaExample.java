// Q27: Lambda Expressions
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class LambdaExample {
    public static void main(String[] args) {
        List<String> names = Arrays.asList("Zara", "Alice", "Mia", "Bob", "Charlie");

        System.out.println("Before sorting: " + names);

        // Sort alphabetically using lambda
        Collections.sort(names, (a, b) -> a.compareTo(b));
        System.out.println("Alphabetical:   " + names);

        // Sort by length using lambda
        names.sort((a, b) -> Integer.compare(a.length(), b.length()));
        System.out.println("By length:      " + names);

        // Sort in reverse order
        names.sort((a, b) -> b.compareTo(a));
        System.out.println("Reverse order:  " + names);
    }
}
