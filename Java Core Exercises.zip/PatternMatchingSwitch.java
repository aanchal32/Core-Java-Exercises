// Q30: Pattern Matching for switch (Java 21)
public class PatternMatchingSwitch {

    static String describe(Object obj) {
        return switch (obj) {
            case Integer i  -> "Integer with value: " + i;
            case Double d   -> "Double with value: " + d;
            case String s   -> "String of length " + s.length() + ": \"" + s + "\"";
            case int[] arr  -> "int array of length " + arr.length;
            case null       -> "null value";
            default         -> "Unknown type: " + obj.getClass().getSimpleName();
        };
    }

    public static void main(String[] args) {
        Object[] objects = { 42, 3.14, "Hello", new int[]{1, 2, 3}, null, true };

        for (Object obj : objects) {
            System.out.println(describe(obj));
        }
    }
}
