// Q40: Virtual Threads (Java 21)
import java.util.concurrent.atomic.AtomicInteger;

public class VirtualThreadsExample {

    public static void main(String[] args) throws InterruptedException {
        int threadCount = 100_000;
        AtomicInteger counter = new AtomicInteger(0);

        System.out.println("Launching " + threadCount + " virtual threads...");
        long start = System.currentTimeMillis();

        Thread[] threads = new Thread[threadCount];
        for (int i = 0; i < threadCount; i++) {
            threads[i] = Thread.ofVirtual().start(() -> {
                // Simulate a small task
                counter.incrementAndGet();
            });
        }

        // Wait for all to finish
        for (Thread t : threads) {
            t.join();
        }

        long elapsed = System.currentTimeMillis() - start;
        System.out.println("All " + counter.get() + " virtual threads completed in " + elapsed + " ms.");

        // Comparison with platform (traditional) threads
        System.out.println("\nNow launching 1,000 platform threads for comparison...");
        AtomicInteger counter2 = new AtomicInteger(0);
        long start2 = System.currentTimeMillis();
        Thread[] platformThreads = new Thread[1000];
        for (int i = 0; i < 1000; i++) {
            platformThreads[i] = Thread.ofPlatform().start(() -> counter2.incrementAndGet());
        }
        for (Thread t : platformThreads) t.join();
        long elapsed2 = System.currentTimeMillis() - start2;
        System.out.println("1,000 platform threads completed in " + elapsed2 + " ms.");
        System.out.println("\nVirtual threads are far more lightweight and scalable.");
    }
}
