// Q34: Java Modules - com.utils module descriptor
// File location: com.utils/src/com/utils/module-info.java
module com.utils {
    exports com.utils;
}
