// Q38: Decompile a Class File
// Compile this class and open the .class file in JD-GUI or use CFR from command line
public class DecompileExample {

    private String secret;
    private int value;

    public DecompileExample(String secret, int value) {
        this.secret = secret;
        this.value = value;
    }

    public String processSecret() {
        StringBuilder sb = new StringBuilder();
        for (char c : secret.toCharArray()) {
            sb.append((char)(c + value));
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        DecompileExample obj = new DecompileExample("Hello", 1);
        System.out.println("Processed: " + obj.processSecret());
    }
}

/*
 * Steps to decompile:
 *
 * 1. Compile: javac DecompileExample.java
 *
 * 2a. Using CFR (command line decompiler):
 *     Download: https://www.benf.org/other/cfr/
 *     Run: java -jar cfr-0.152.jar DecompileExample.class
 *
 * 2b. Using JD-GUI:
 *     Download: https://java-decompiler.github.io/
 *     Open the .class file in the GUI
 *
 * 2c. Using IntelliJ IDEA:
 *     Simply open the .class file – IDEA decompiles it automatically
 *
 * Analysis:
 * - The decompiler reconstructs the original Java source from bytecode
 * - Inner workings like StringBuilder usage in string concatenation become visible
 * - Obfuscated code (variable names like a, b, c) shows what bytecode can hide
 * - This is useful for: understanding third-party libraries, security auditing,
 *   recovering lost source code
 */
