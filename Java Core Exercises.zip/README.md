# Core Java Exercises

41 Java programs covering the full Core Java syllabus — from Hello World to Virtual Threads.

## 📁 Project Structure

```
CoreJava/
├── basics/          # Q1–Q16: Fundamentals, control flow, arrays, strings
├── oop/             # Q17–Q19: Classes, inheritance, interfaces
├── exceptions/      # Q20–Q21: Try-catch, custom exceptions
├── io/              # Q22–Q23: File read/write
├── collections/     # Q24–Q25: ArrayList, HashMap
├── concurrency/     # Q26, Q40, Q41: Threads, Virtual Threads, ExecutorService
├── advanced/        # Q27–Q30, Q37–Q39: Lambdas, Streams, Records, Pattern Matching,
│                    #                    Bytecode, Reflection
├── jdbc/            # Q31–Q33: JDBC with SQLite (insert, update, transactions)
├── modules/         # Q34: Java Module System (com.utils + com.greetings)
└── network/         # Q35–Q36: TCP Chat (Server + Client), HTTP Client API
```

## ✅ Exercise Index

| # | Topic | File |
|---|-------|------|
| 1 | Hello World | `basics/HelloWorld.java` |
| 2 | Simple Calculator | `basics/SimpleCalculator.java` |
| 3 | Even or Odd Checker | `basics/EvenOddChecker.java` |
| 4 | Leap Year Checker | `basics/LeapYearChecker.java` |
| 5 | Multiplication Table | `basics/MultiplicationTable.java` |
| 6 | Data Type Demonstration | `basics/DataTypeDemo.java` |
| 7 | Type Casting | `basics/TypeCastingExample.java` |
| 8 | Operator Precedence | `basics/OperatorPrecedence.java` |
| 9 | Grade Calculator | `basics/GradeCalculator.java` |
| 10 | Number Guessing Game | `basics/NumberGuessingGame.java` |
| 11 | Factorial Calculator | `basics/FactorialCalculator.java` |
| 12 | Method Overloading | `basics/MethodOverloading.java` |
| 13 | Recursive Fibonacci | `basics/RecursiveFibonacci.java` |
| 14 | Array Sum & Average | `basics/ArraySumAverage.java` |
| 15 | String Reversal | `basics/StringReversal.java` |
| 16 | Palindrome Checker | `basics/PalindromeChecker.java` |
| 17 | Class & Object (Car) | `oop/Car.java` |
| 18 | Inheritance (Animal/Dog) | `oop/InheritanceExample.java` |
| 19 | Interface (Guitar/Piano) | `oop/InterfaceExample.java` |
| 20 | Try-Catch | `exceptions/TryCatchExample.java` |
| 21 | Custom Exception | `exceptions/CustomExceptionExample.java` |
| 22 | File Writing | `io/FileWritingExample.java` |
| 23 | File Reading | `io/FileReadingExample.java` |
| 24 | ArrayList | `collections/ArrayListExample.java` |
| 25 | HashMap | `collections/HashMapExample.java` |
| 26 | Thread Creation | `concurrency/ThreadCreationExample.java` |
| 27 | Lambda Expressions | `advanced/LambdaExample.java` |
| 28 | Stream API | `advanced/StreamAPIExample.java` |
| 29 | Records (Java 16+) | `advanced/RecordsExample.java` |
| 30 | Pattern Matching Switch (Java 21) | `advanced/PatternMatchingSwitch.java` |
| 31 | Basic JDBC Connection | `jdbc/BasicJDBCConnection.java` |
| 32 | JDBC Insert & Update | `jdbc/StudentDAO.java` |
| 33 | JDBC Transactions | `jdbc/TransactionHandling.java` |
| 34 | Java Modules | `modules/` |
| 35 | TCP Client-Server Chat | `network/TCPServer.java`, `network/TCPClient.java` |
| 36 | HTTP Client API | `network/HTTPClientExample.java` |
| 37 | Bytecode Inspection (javap) | `advanced/BytecodeInspection.java` |
| 38 | Decompile a Class File | `advanced/DecompileExample.java` |
| 39 | Reflection API | `advanced/ReflectionExample.java` |
| 40 | Virtual Threads (Java 21) | `concurrency/VirtualThreadsExample.java` |
| 41 | ExecutorService & Callable | `concurrency/ExecutorServiceExample.java` |

## 🛠️ Prerequisites

- **Java 21+** (required for Virtual Threads Q40, Pattern Matching Q30, Records Q29)
- **SQLite JDBC driver** for JDBC exercises (Q31–Q33): [sqlite-jdbc on Maven Central](https://mvnrepository.com/artifact/org.xerial/sqlite-jdbc)

## 🚀 How to Compile & Run

### Single file (most exercises):
```bash
javac basics/HelloWorld.java
java -cp basics HelloWorld
```

### With SQLite (JDBC exercises):
```bash
# Download sqlite-jdbc-3.x.x.jar first
javac -cp .:sqlite-jdbc.jar jdbc/BasicJDBCConnection.java
java  -cp .:sqlite-jdbc.jar BasicJDBCConnection
```

### TCP Chat (Q35) — two terminals:
```bash
# Terminal 1:
javac network/TCPServer.java && java -cp network TCPServer

# Terminal 2:
javac network/TCPClient.java && java -cp network TCPClient
```

### Java Modules (Q34):
```bash
cd modules
javac -d mods/com.utils  com.utils/src/module-info.java  com.utils/src/com/utils/StringUtils.java
javac --module-path mods -d mods/com.greetings  com.greetings/src/module-info.java  com.greetings/src/com/greetings/Main.java
java  --module-path mods -m com.greetings/com.greetings.Main
```

## 📌 Notes

- All exercises are self-contained single files (except Q34 modules and Q35 TCP chat).
- JDBC exercises use **SQLite** so no MySQL/PostgreSQL server setup is needed.
- Exercises Q29, Q30, Q40 require **Java 16+**, **Java 21**, and **Java 21** respectively.
