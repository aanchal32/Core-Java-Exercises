// Q35: TCP Chat - Client
// Run this AFTER the server is started: javac TCPClient.java && java TCPClient
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class TCPClient {
    public static void main(String[] args) throws Exception {
        String host = "localhost";
        int port = 5000;

        try (Socket socket = new Socket(host, port)) {
            System.out.println("Connected to server at " + host + ":" + port);

            BufferedReader in  = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter    out = new PrintWriter(socket.getOutputStream(), true);
            Scanner        sc  = new Scanner(System.in);

            // Thread to read messages from server
            Thread readerThread = new Thread(() -> {
                try {
                    String msg;
                    while ((msg = in.readLine()) != null) {
                        System.out.println("[Server]: " + msg);
                    }
                } catch (Exception ignored) {}
            });
            readerThread.start();

            // Main thread sends messages to server
            System.out.println("Type messages to send (type 'exit' to quit):");
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                out.println(line);
                if (line.equalsIgnoreCase("exit")) break;
            }
        }
    }
}
