// Q41: Executor Service and Callable
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ExecutorServiceExample {

    // A Callable that computes the square of a number with a simulated delay
    static class SquareTask implements Callable<Integer> {
        private final int number;

        SquareTask(int number) {
            this.number = number;
        }

        @Override
        public Integer call() throws Exception {
            Thread.sleep(100); // simulate work
            int result = number * number;
            System.out.println(Thread.currentThread().getName() + " computed " + number + "^2 = " + result);
            return result;
        }
    }

    public static void main(String[] args) throws Exception {
        int poolSize = 4;
        int taskCount = 10;

        ExecutorService executor = Executors.newFixedThreadPool(poolSize);
        List<Future<Integer>> futures = new ArrayList<>();

        System.out.println("Submitting " + taskCount + " tasks to a pool of " + poolSize + " threads...\n");

        // Submit all tasks
        for (int i = 1; i <= taskCount; i++) {
            futures.add(executor.submit(new SquareTask(i)));
        }

        // Collect all results
        System.out.println("\nResults:");
        int totalSum = 0;
        for (int i = 0; i < futures.size(); i++) {
            int result = futures.get(i).get(); // blocks until result is ready
            totalSum += result;
            System.out.println("Task " + (i + 1) + " result: " + result);
        }

        System.out.println("\nSum of all squares (1² + 2² + ... + 10²) = " + totalSum);

        executor.shutdown();
        System.out.println("Executor shut down.");
    }
}
