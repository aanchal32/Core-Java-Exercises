// Q25: HashMap Example
import java.util.HashMap;
import java.util.Scanner;

public class HashMapExample {
    public static void main(String[] args) {
        HashMap<Integer, String> studentMap = new HashMap<>();
        Scanner sc = new Scanner(System.in);

        // Pre-populate some entries
        studentMap.put(101, "Alice");
        studentMap.put(102, "Bob");
        studentMap.put(103, "Charlie");

        System.out.println("Add more students (enter 0 as ID to stop):");
        while (true) {
            System.out.print("Student ID: ");
            int id = sc.nextInt();
            if (id == 0) break;
            sc.nextLine(); // consume newline
            System.out.print("Student Name: ");
            String name = sc.nextLine();
            studentMap.put(id, name);
        }

        System.out.print("\nEnter student ID to look up: ");
        int lookupId = sc.nextInt();
        String result = studentMap.get(lookupId);
        if (result != null) {
            System.out.println("Student found: " + result);
        } else {
            System.out.println("No student found with ID " + lookupId);
        }
        sc.close();
    }
}
