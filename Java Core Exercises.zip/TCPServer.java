// Q35: TCP Chat - Server
// Run this FIRST in one terminal: javac TCPServer.java && java TCPServer
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class TCPServer {
    public static void main(String[] args) throws Exception {
        int port = 5000;
        System.out.println("Server listening on port " + port + "...");

        try (ServerSocket serverSocket = new ServerSocket(port);
             Socket clientSocket = serverSocket.accept()) {

            System.out.println("Client connected: " + clientSocket.getInetAddress());

            BufferedReader in  = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter    out = new PrintWriter(clientSocket.getOutputStream(), true);
            Scanner        sc  = new Scanner(System.in);

            // Thread to read messages from client
            Thread readerThread = new Thread(() -> {
                try {
                    String msg;
                    while ((msg = in.readLine()) != null) {
                        System.out.println("[Client]: " + msg);
                    }
                } catch (Exception ignored) {}
            });
            readerThread.start();

            // Main thread sends messages to client
            System.out.println("Type messages to send (type 'exit' to quit):");
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                out.println(line);
                if (line.equalsIgnoreCase("exit")) break;
            }
        }
    }
}
