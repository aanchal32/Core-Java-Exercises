// Q33: Transaction Handling in JDBC (SQLite)
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class TransactionHandling {

    private static final String DB_URL = "jdbc:sqlite:bank.db";

    static void setupDatabase() throws SQLException {
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement()) {
            stmt.execute("CREATE TABLE IF NOT EXISTS accounts (id INTEGER PRIMARY KEY, owner TEXT, balance REAL)");
            stmt.execute("INSERT OR IGNORE INTO accounts VALUES (1, 'Alice', 1000.00)");
            stmt.execute("INSERT OR IGNORE INTO accounts VALUES (2, 'Bob',   500.00)");
        }
        System.out.println("Database initialized.");
    }

    static void transfer(int fromId, int toId, double amount) {
        String debit  = "UPDATE accounts SET balance = balance - ? WHERE id = ?";
        String credit = "UPDATE accounts SET balance = balance + ? WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL)) {
            conn.setAutoCommit(false); // Start transaction

            try (PreparedStatement debitStmt  = conn.prepareStatement(debit);
                 PreparedStatement creditStmt = conn.prepareStatement(credit)) {

                // Debit from sender
                debitStmt.setDouble(1, amount);
                debitStmt.setInt(2, fromId);
                int debitRows = debitStmt.executeUpdate();

                // Simulate failure: uncomment to test rollback
                // if (true) throw new SQLException("Simulated failure!");

                // Credit to receiver
                creditStmt.setDouble(1, amount);
                creditStmt.setInt(2, toId);
                int creditRows = creditStmt.executeUpdate();

                if (debitRows == 1 && creditRows == 1) {
                    conn.commit(); // Both succeeded
                    System.out.printf("Transfer of %.2f from account %d to %d committed.%n", amount, fromId, toId);
                } else {
                    conn.rollback();
                    System.out.println("Transfer failed — rolled back.");
                }

            } catch (SQLException e) {
                conn.rollback();
                System.out.println("Transaction rolled back due to error: " + e.getMessage());
            }

        } catch (SQLException e) {
            System.out.println("Connection error: " + e.getMessage());
        }
    }

    public static void main(String[] args) throws SQLException {
        setupDatabase();
        transfer(1, 2, 200.00); // Alice sends 200 to Bob
    }
}
