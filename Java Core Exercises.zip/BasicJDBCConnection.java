// Q31: Basic JDBC Connection (SQLite example – no server setup needed)
// Add sqlite-jdbc dependency to your project (e.g., via Maven or download jar)
// Maven: <dependency><groupId>org.xerial</groupId><artifactId>sqlite-jdbc</artifactId><version>3.43.0.0</version></dependency>

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class BasicJDBCConnection {

    // Using SQLite for easy local testing (no server required)
    private static final String DB_URL = "jdbc:sqlite:school.db";

    public static void main(String[] args) {
        // Step 1: Create table and insert sample data
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement()) {

            stmt.execute("CREATE TABLE IF NOT EXISTS students (id INTEGER PRIMARY KEY, name TEXT, grade TEXT)");
            stmt.execute("INSERT OR IGNORE INTO students VALUES (1, 'Alice', 'A')");
            stmt.execute("INSERT OR IGNORE INTO students VALUES (2, 'Bob', 'B')");
            stmt.execute("INSERT OR IGNORE INTO students VALUES (3, 'Charlie', 'A')");

            System.out.println("Connected to database: school.db");
            System.out.println("Students table ready.\n");

            // Step 2: Execute SELECT query
            ResultSet rs = stmt.executeQuery("SELECT * FROM students");
            System.out.printf("%-5s %-15s %-5s%n", "ID", "Name", "Grade");
            System.out.println("-------------------------");
            while (rs.next()) {
                System.out.printf("%-5d %-15s %-5s%n",
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("grade"));
            }

        } catch (Exception e) {
            System.out.println("JDBC Error: " + e.getMessage());
        }
    }
}
