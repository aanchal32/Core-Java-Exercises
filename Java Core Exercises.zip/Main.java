// Q34: Main class in com.greetings module
package com.greetings;

import com.utils.StringUtils;

public class Main {
    public static void main(String[] args) {
        System.out.println(StringUtils.greet("Java Developer"));
        System.out.println(StringUtils.repeat("Module! ", 3));
    }
}

/*
 * To compile and run from the CoreJava/modules directory:
 *
 * javac -d mods/com.utils  com.utils/src/module-info.java  com.utils/src/com/utils/StringUtils.java
 * javac --module-path mods -d mods/com.greetings  com.greetings/src/module-info.java  com.greetings/src/com/greetings/Main.java
 * java  --module-path mods -m com.greetings/com.greetings.Main
 */
